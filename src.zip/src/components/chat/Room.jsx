import React from 'react';

import InputField from './InputField';

const Room = () => {
  return (
    <div>
      <InputField />
    </div>
  );
};

export default Room;
