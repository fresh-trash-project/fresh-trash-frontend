import List from '../components/product/List';

const ProductsList = () => {
  return (
    <div>
      <List />
    </div>
  );
};
export default ProductsList;
