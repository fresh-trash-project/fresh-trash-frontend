import React from 'react';

import DetailProduct from '../components/product/DetailProduct';
const ProductDetail = () => {
  return (
    <div>
      <DetailProduct />
    </div>
  );
};
export default ProductDetail;
