import DetailAuction from '../components/auction/DetailAuction';

const AuctionDetail = () => {
  return (
    <div>
      <DetailAuction />
    </div>
  );
};
export default AuctionDetail;
