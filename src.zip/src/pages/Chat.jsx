import Room from '../components/chat/Room';

const Chat = () => {
  return (
    <div>
      <Room />
    </div>
  );
};
export default Chat;
