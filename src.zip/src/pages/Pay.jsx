import PayContent from '../components/pay/PayContent';
const Pay = () => {
  return (
    <div>
      <PayContent />
    </div>
  );
};
export default Pay;
