import List from '../components/auction/List';

const AuctionList = () => {
  return (
    <div>
      <List />
    </div>
  );
};
export default AuctionList;
