import Edit from '../components/product/Edit';

const ProductEdit = () => {
  return (
    <div>
      <Edit />
    </div>
  );
};

export default ProductEdit;
