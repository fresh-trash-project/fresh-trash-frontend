import React from 'react';
import AddForm from '../components/form/AddForm';

const ProductAdd = () => {
  return (
    <div>
      <AddForm />
    </div>
  );
};
export default ProductAdd;
