import { atom } from 'recoil';

export const postsState = atom({
  key: 'postState',
  default: [],
});
