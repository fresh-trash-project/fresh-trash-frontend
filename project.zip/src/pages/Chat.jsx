import Room from '../components/chat/Room';
import Header from '../components/common/header/Header';
const Chat = () => {
  return (
    <div>
      <Header />
      <Room />
    </div>
  );
};
export default Chat;
